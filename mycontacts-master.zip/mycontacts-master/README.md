#Please check out MyContact project

To run this project:
1. Please download node.js
2. npm install
3. npm start  // to srart the default server on port 8000
4. open broswer :  http://localhost:8000/app/#/contacts


Functionality:

- add a contact

- list contacts

- edit contact

- delete contact